/* Gamma Price Map v0.22: real timestamps, observed zones, fail closed. */
let gammaMapAsset = 'SPX';
function renderPriceMap_(g) {
  const box = document.getElementById('gPriceMap');
  if (!box) return;
  box.replaceChildren();
  const add = (tag, text) => { const n = document.createElement(tag); n.textContent = text; box.append(n); return n; };
  add('h2', 'Gamma Price Map — سعر SPX / 5 دقائق');
  add('p', 'Macro → Weekly Context → Daily Rhythm → Order Flow. المستويات سياق تقديري، مو إشارة تنفيذ.');
  const select = add('select', ''); select.setAttribute('aria-label', 'مصدر مستويات Price Map');
  for (const a of ['SPX', 'SPY', 'Combined']) {
    const o = document.createElement('option'); o.value = a; o.textContent = a === 'SPY' ? 'SPY → SPX' : a;
    select.append(o);
  }
  select.value = gammaMapAsset;
  select.onchange = () => { gammaMapAsset = select.value; renderPriceMap_(g); };
  add('p', 'المحور العمودي SPX دائماً. Combined = تداخل مناطق SPX وSPY بنفس الإشارة، وليس جمع GEX. الخريطة للكل؛ فلاتر الاستحقاق أدناه تخص الرسوم التفصيلية.').className = 'src';
  const history = g && g.price_history;
  let points = history && history.ok ? (history.points || []).filter(p => Number.isFinite(p.close) && p.close > 0 && Number.isFinite(Date.parse(p.time)) && Date.parse(p.time) <= Date.now()) : [];
  points.sort((a,b) => Date.parse(a.time)-Date.parse(b.time));
  // Display only the last observed NY date; avoid connecting overnight gaps.
  const day = t => Number.isFinite(Date.parse(t)) ? new Date(t).toLocaleDateString('en-CA', {timeZone:'America/New_York'}) : null;
  if (points.length) { const lastDay = day(points[points.length-1].time); points = points.filter(p => day(p.time) === lastDay); }
  if (points.length < 2) { add('p', 'شارت السعر غير متاح: ماكو سلسلة SPX زمنية صالحة. ما نرسم أسعار افتراضية.'); return; }
  const last = Date.parse(points[points.length-1].time), age = (Date.now()-last)/60000;
  add('p', 'مصدر السعر: ' + history.source + ' · آخر شمعة مكتملة: ' + new Date(last).toLocaleString('ar-IQ', {timeZone:'Asia/Baghdad'}) + ' بغداد · العمر ' + Math.round(age) + ' دقيقة' + (age > 30 ? ' — سعر متأخر' : '')).className = 'src';
  const fresh = g && g.ok && g.schema_version >= 2 && Date.now()-Date.parse(g.snapshot_utc) >= 0 && Date.now()-Date.parse(g.snapshot_utc) < 30*60000 && g.status === 'fresh';
  let source = gammaMapAsset === 'SPY' ? g.spy : gammaMapAsset === 'Combined' ? g.combined : g;
  const sourceAge = source ? (Date.now()-Date.parse(source.snapshot_utc))/60000 : NaN;
  const sourceFresh = gammaMapAsset !== 'SPY' || (source && source.status === 'fresh' && sourceAge >= 0 && sourceAge < 30);
  const alignedPrice = age <= 30 && g && day(last) === day(g.snapshot_utc);
  const available = fresh && source && source.ok && sourceFresh && alignedPrice;
  const levels = [], zones = [];
  if (available) {
    for (const z of source.zones || []) {
      const lo = gammaMapAsset === 'SPY' ? z.low_x : z.low, hi = gammaMapAsset === 'SPY' ? z.high_x : z.high;
      if (Number.isFinite(lo) && Number.isFinite(hi) && lo <= hi) zones.push({lo, hi, sign:z.sign});
    }
    if (gammaMapAsset !== 'Combined') for (const [label,key] of [['Call Wall','call_wall'],['Put Wall','put_wall'],['Gamma Flip','gamma_flip']]) {
      const v = source[key + (gammaMapAsset === 'SPY' ? '_x' : '')];
      if (Number.isFinite(v) && v > 0) levels.push({label,v});
    }
    add('p', 'وقت بيانات المستويات: ' + g.snapshot_utc + ' · متاحة منذ الجمع: ' + g.fetched_utc + ' · المناطق من Strikes فعلية، بإشارة Net GEX المقدّرة.').className='src';
    if (gammaMapAsset === 'Combined' && !zones.length) add('p','ماكو تداخل مناطق موثّق بهاللقطة.');
  } else add('p', 'المستويات معطلة: ' + (!fresh ? 'لقطة Gamma قديمة أو غير صالحة أو تحتاج إعادة جمع بالإصدار الجديد.' : !alignedPrice ? 'السعر متأخر أو من جلسة مختلفة عن Gamma.' : (source && source.reason) || 'المصدر غير متاح أو متأخر.'));
  // No uniform or historical regime coloring based merely on net sign.
  add('p', 'خلفية Gamma Regime معطلة: ما متوفر نموذج repricing مُعاير ومتحقق منه.').className='review-badge';
  const W=1100,H=480,L=80,R=160,T=24,B=65;
  const start=Date.parse(points[0].time), fetched = Date.parse(g.fetched_utc);
  const onset=Number.isFinite(fetched) ? Math.max(start,fetched) : last;
  const end=Math.max(last+5*60000,available ? onset+45*60000 : last+5*60000);
  const all=points.map(p=>p.close).concat(levels.map(p=>p.v),zones.flatMap(z=>[z.lo,z.hi]));
  let low=Math.min(...all),high=Math.max(...all),pad=Math.max(3,(high-low)*.08); low-=pad; high+=pad;
  const x=t=>L+(t-start)/(end-start)*(W-L-R), y=v=>T+(high-v)/(high-low)*(H-T-B);
  const ns='http://www.w3.org/2000/svg', svg=document.createElementNS(ns,'svg');
  svg.setAttribute('viewBox',`0 0 ${W} ${H}`); svg.setAttribute('role','img'); svg.setAttribute('aria-label','سعر SPX عبر الزمن ومستويات Gamma الحالية، لا تاريخ افتراضي');
  svg.style.cssText='width:100%;min-width:680px;display:block;direction:ltr;background:var(--bg,#111827)';
  const draw=(tag,attrs,text)=>{ const n=document.createElementNS(ns,tag); for(const [k,v] of Object.entries(attrs)) n.setAttribute(k,v); if(text)n.textContent=text; svg.append(n);return n; };
  for(let i=0;i<=5;i++){const v=low+(high-low)*i/5;draw('line',{x1:L,x2:W-R,y1:y(v),y2:y(v),stroke:'#7b8796','stroke-opacity':'.25'});draw('text',{x:L-8,y:y(v)+5,fill:'#94a3b8','text-anchor':'end','font-size':16},v.toFixed(1));}
  for(let i=0;i<=4;i++){const t=start+(end-start)*i/4;draw('text',{x:x(t),y:H-30,fill:'#94a3b8','font-size':15,'text-anchor':'middle'},new Date(t).toLocaleTimeString('en-GB',{timeZone:'Asia/Baghdad',hour:'2-digit',minute:'2-digit'}));}
  const sx=x(onset), ex=W-R;
  for(const z of zones){const color=z.sign==='positive'?'#2fbf71':'#e5484d';draw('rect',{x:sx,y:y(z.hi),width:Math.max(0,ex-sx),height:Math.max(2,y(z.lo)-y(z.hi)),fill:color,'fill-opacity':'.2'});draw('text',{x:ex+6,y:y((z.lo+z.hi)/2),fill:color,'font-size':13},z.lo.toFixed(1)+'–'+z.hi.toFixed(1));}
  for(const l of levels){const color=l.label==='Call Wall'?'#2fbf71':l.label==='Put Wall'?'#e5484d':'#60a5fa';draw('line',{x1:sx,x2:ex,y1:y(l.v),y2:y(l.v),stroke:color,'stroke-width':2,'stroke-dasharray':'6 4'});const n=draw('text',{x:ex+6,y:y(l.v)-5,fill:color,'font-size':14},l.label+' '+l.v.toFixed(1));const title=document.createElementNS(ns,'title');title.textContent=l.label+' '+l.v;n.append(title);}
  let path='',prev=null;
  for(const p of points){const t=Date.parse(p.time);path+=(prev===null || t-prev>6*60000?'M':'L')+x(t).toFixed(2)+','+y(p.close).toFixed(2)+' ';prev=t;}
  draw('path',{d:path,fill:'none',stroke:'#60a5fa','stroke-width':2.5});
  if(available) {draw('line',{x1:sx,x2:sx,y1:T,y2:H-B,stroke:'#d4a84b','stroke-dasharray':'3 4'});draw('text',{x:sx+5,y:T+16,fill:'#d4a84b','font-size':13},'Snapshot available →');}
  const wrap=add('div','');wrap.className='gmap-scroll';wrap.style.overflowX='auto';wrap.append(svg);
  if (levels.length) add('p',levels.map(l=>l.label+': '+l.v.toFixed(1)).join(' · '));
  add('p','على الموبايل: اسحب الشارت أفقياً لقراءة الأسعار والتوقيت.').className='src';
  add('p','الزمن بتوقيت بغداد. المستويات تبدأ من وقت إتاحة اللقطة؛ المساحة بعدها عرض للمستويات الحالية، مو توقع لسعر مستقبلي.').className='src';
  const metadata=document.createElement('details');metadata.className='gmap-meta';
  const metaTitle=document.createElement('summary');metaTitle.textContent='المصادر والتوقيت وحدود الحساب';metadata.append(metaTitle);
  for(const n of [...box.querySelectorAll('p.src')])metadata.append(n);
  box.append(metadata);
}
