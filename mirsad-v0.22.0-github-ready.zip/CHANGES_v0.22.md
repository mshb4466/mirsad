# التغييرات مقارنة بملف ZIP الأصلي

آخر نسختين مقدمتين من المستخدم (`gamma.py` و`index.html`) هما أساس دمج السلال التقويمية والمرجع ذي خمسة أيام وإصلاح قائمة روابط SPY. التعديلات الجديدة مبنية فوقهما.

## ملفات أصلية تغيرت

- `.github/workflows/gamma.yml`
- `.github/workflows/mirsad.yml`
- `README.md`
- `dashboard.py`
- `docs/index.html`
- `gamma.py`
- `index.html`
- `requirements.txt`
- `tests_gamma.py`
- `workflow-gamma.yml`
- `workflow-mirsad.yml`

## ملفات جديدة

- `.github/workflows/checks.yml`
- `.gitignore`
- `CHANGES_v0.22.md`
- `RELEASE_TESTS_v0.22.md`
- `UPGRADE_v0.22_AR.md`
- `docs/gamma-map.js`
- `docs/layout-v022.css`
- `docs/layout-v022.js`
- `gamma-map.js`
- `layout-v022.css`
- `layout-v022.js`
- `package.json`
- `run_tests.py`
- `tests_gamma_v022.py`
- `tests_ui_fixture.py`
- `tests_ui_v022.cjs`

## حفظ محرك الماكرو

تم التحقق بالمطابقة الثنائية من الملفات التالية مع ZIP الأصلي:

- `macro.py`
- `bias.py`
- `verdict.py`
- `runner.py`
- `collector.py`
- `actuals.py`
- `release_impact.py`
- `events_ctx.py`
- `safety.py`
- `quality.py`
- `health.py`
- `bls.py`
- `indicators.py`
- `auction.py`
- `backtest.py`

`dashboard.py` تغير فيه رقم الإصدار فقط. تم الاحتفاظ بملف backtest.json الأصلي، واستبعاد ملفات الاختبار واللقطات الحية والسجلات المحلية والأسرار والمكتبات المثبتة من الحزمة.
