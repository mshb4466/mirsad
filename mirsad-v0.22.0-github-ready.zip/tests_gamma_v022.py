"""No network: invalid inputs, expiry, synchronization, zones, and as-of data."""
import copy
import math
import tempfile
import unittest
import types
from datetime import datetime, timedelta, timezone, date
from unittest.mock import patch
import gamma

T = datetime(2026,10,19,14,0,tzinfo=timezone.utc)

def raw_chain(asset='SPX', timestamp=None):
    spot=700 if asset=='SPY' else 7000
    rows=[]
    for i in range(-24,25):
        k=spot+i*(1 if asset=='SPY' else 5)
        for kind in 'CP':
            rows.append({'option': ('SPY' if asset=='SPY' else 'SPXW')+'261020'+kind+f'{int(k*1000):08d}',
                         'gamma':.01,'iv':.2,'open_interest':1000+(300 if kind=='C' and i>0 else 0)})
    return {'timestamp':timestamp or T.isoformat(),'data':{'current_price':spot,'options':rows}}

def spy_ref(at=T):
    return {'ratio':10.,'spy_ref':700.,'spx_ref':7000.,'ref_time_utc':at.isoformat(),'ref_gap_min':10.,'mode':'live'}

class GammaAudit(unittest.TestCase):
    def build(self, raw=None):
        return gamma.build(raw or raw_chain(), fetched=T+timedelta(minutes=10),with_es=False)

    def test_timezone_offsets_and_dst(self):
        self.assertEqual(gamma.parse_ts('2026-10-19T10:00:00-04:00'), T)
        self.assertEqual(gamma.to_ny(datetime(2026,1,20,14,tzinfo=timezone.utc)).hour,9)
        self.assertEqual(gamma.to_ny(T).hour,10)

    def test_bad_contracts_are_not_exposure(self):
        raw=raw_chain(); base=len(raw['data']['options'])
        for v in (float('nan'),float('inf'),-1,True):
            c=copy.deepcopy(raw['data']['options'][0]);c['option']=c['option'].replace('261020','261021');c['gamma']=v
            rr=copy.deepcopy(raw);rr['data']['options'].append(c)
            self.assertEqual(len(gamma.parse_chain(rr)[2]),base)

    def test_duplicates_do_not_double_exposure(self):
        raw=raw_chain(); a=self.build(raw)
        raw['data']['options']*=2
        self.assertEqual(self.build(raw)['net_gex'],a['net_gex'])

    def test_coverage_rejects_major_missing_greeks(self):
        raw=raw_chain()
        for o in raw['data']['options'][:40]: o['gamma']=None
        self.assertFalse(self.build(raw)['ok'])

    def test_empty_and_one_sided_do_not_invent_walls(self):
        self.assertEqual(gamma._walls([{'k':7000,'call':0,'put':0}],7000),(None,None))
        self.assertFalse(self.build({'timestamp':T.isoformat(),'data':{'current_price':7000,'options':raw_chain()['data']['options'][:2]}})['ok'])

    def test_no_unverified_regime_or_flip(self):
        s=self.build();self.assertTrue(s['ok']);self.assertIsNone(s['gamma_flip'])
        self.assertFalse(s['regime_model']['valid'])

    def test_money_units_and_buckets_conserve(self):
        spot,ts,cs=gamma.parse_chain(raw_chain());r=gamma.compute(spot,cs,ts)
        expected=sum(c['gamma']*c['oi']*100*spot**2*.01*(1 if c['kind']=='C' else -1) for c in cs)
        self.assertAlmostEqual(r['net_gex'],expected)
        self.assertAlmostEqual(sum(b['net_gex'] for b in r['buckets'].values()),expected)
        self.assertEqual(sum(b['n'] for b in r['buckets'].values()),r['n_contracts'])

    def test_calendar_edges_have_one_bucket(self):
        for start in (date(2026,10,30),date(2026,10,31),date(2026,12,31),date(2027,1,1)):
            bounds=gamma.bucket_bounds(start)
            for i in range(45):
                d=start+timedelta(days=i)
                hits=[b for b,(lo,hi) in bounds.items() if lo<=d and (hi is None or d<=hi)]
                self.assertEqual(len(hits),1)
                self.assertEqual(gamma.bucket_of(d,start),hits[0])

    def test_expired_and_am_excluded(self):
        _,_,cs=gamma.parse_chain(raw_chain())
        cs=[dict(c,exp='261019',root='SPX') for c in cs]
        self.assertEqual(gamma.compute(7000,cs,T)['n_contracts'],0)
        cs=[dict(c,root='SPXW') for c in cs]
        self.assertGreater(gamma.compute(7000,cs,T)['n_contracts'],0)
        self.assertEqual(gamma.compute(7000,cs,T.replace(hour=20))['n_contracts'],0)

    def test_spy_sync_and_ratio_fail_closed(self):
        good=gamma.build_spy(T,T+timedelta(minutes=10),T.date(),ref=spy_ref(),raw=raw_chain('SPY'))
        self.assertTrue(good['ok']); self.assertEqual(good['spot'],700)
        self.assertTrue(all(abs(r['kx']-r['k']*10)<.01 for r in good['strikes']))
        ref=spy_ref(T-timedelta(days=1))
        self.assertFalse(gamma.build_spy(T,T,T.date(),ref=ref,raw=raw_chain('SPY'))['ok'])
        ref=spy_ref();ref['ratio']=11
        self.assertFalse(gamma.build_spy(T,T,T.date(),ref=ref,raw=raw_chain('SPY'))['ok'])

    def test_future_timestamp_rejected(self):
        self.assertFalse(self.build(raw_chain(timestamp=(T+timedelta(hours=1)).isoformat()))['ok'])
        self.assertEqual(gamma.status_of(T+timedelta(hours=1),T),'stale')
        self.assertNotEqual(gamma.ref_mode(T+timedelta(minutes=1),T),'live')

    def test_zones_use_observed_strikes_and_sign(self):
        rows=[{'k':k,'net':net} for k,net in [(1,1),(2,10),(3,11),(4,0),(5,-12),(6,-13),(7,1),(20,14)]]
        zs=gamma.zones(rows)
        for z in zs:
            self.assertIn(z['low'],[r['k'] for r in rows]);self.assertIn(z['high'],[r['k'] for r in rows])
            self.assertTrue(all((next(r['net'] for r in rows if r['k']==k)>0)==(z['sign']=='positive') for k in z['strikes']))
        self.assertFalse(any(z['low']<20 and z['high']==20 for z in zs))
        self.assertEqual(gamma.zones([{'k':1,'net':0}]),[])

    def test_combined_is_overlap_not_gex_sum(self):
        s=self.build();s['zones']=[{'low':6990,'high':7010,'sign':'positive'}]
        s['spy']={'ok':True,'snapshot_utc':T.isoformat(),'status':'fresh','zones':[{'low_x':7000,'high_x':7020,'sign':'positive'}]}
        c=gamma.combined(s);self.assertTrue(c['ok']);self.assertEqual(c['zones'][0]['low'],7000)
        self.assertEqual(c['zones'][0]['high'],7010);self.assertNotIn('net_gex',c)
        s['spy']['status']='stale';self.assertFalse(gamma.combined(s)['ok'])
        s['spy']['status']='fresh';s['spy']['zones'][0]['sign']='negative'
        self.assertEqual(gamma.combined(s)['zones'],[])

    def test_fetch_tries_url_list_not_list_request(self):
        calls=[]
        class Response:
            def __enter__(self):return self
            def __exit__(self,*a):pass
            def read(self):return b'{"ok":true}'
        def open_(request,**kw):
            calls.append(request.full_url)
            if len(calls)==1:raise OSError('source down')
            return Response()
        with patch('gamma.urllib.request.urlopen',open_),patch('gamma.time.sleep'):
            raw,meta=gamma.fetch(['https://a.example/x','https://b.example/x'],tries=1)
        self.assertTrue(raw['ok']);self.assertEqual(len(calls),2)

    def test_archive_no_future_knowledge(self):
        with tempfile.TemporaryDirectory() as root:
            s=self.build();gamma.archive(s,root)
            self.assertIsNone(gamma.last_before_open('2026-10-19',root))

    def test_price_history_only_completed_finite_bars(self):
        class Stamp:
            def __init__(self,dt):self.dt=dt
            def to_pydatetime(self):return self.dt
        class Frame:
            def iterrows(self):
                return iter([(Stamp(T-timedelta(minutes=10)),{'Close':7000}),
                             (Stamp(T),{'Close':7001}),
                             (Stamp(T-timedelta(minutes=15)),{'Close':float('nan')})])
        fake=types.SimpleNamespace(Ticker=lambda _:types.SimpleNamespace(history=lambda **kw:Frame()))
        with patch.dict('sys.modules',{'yfinance':fake}):
            h=gamma.price_history(T+timedelta(minutes=1))
        self.assertEqual(len(h['points']),1)
        self.assertEqual(h['points'][0]['time'],(T-timedelta(minutes=5)).isoformat())
        self.assertFalse(h['ok'])

    def test_source_failure_still_saves_independent_price(self):
        with tempfile.TemporaryDirectory() as root, patch('gamma.price_history',return_value={'ok':True,'points':[1,2]}),patch('gamma.fetch',side_effect=RuntimeError('HTTP 403')):
            self.assertIsNone(gamma.collect(root))
            self.assertTrue(gamma._rjson(root+'/price.json')['ok'])

if __name__=='__main__':unittest.main()
