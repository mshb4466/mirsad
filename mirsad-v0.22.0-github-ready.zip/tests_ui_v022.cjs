const {chromium}=require('playwright');
const fs=require('fs'),path=require('path'),http=require('http'),assert=require('assert');
const root=path.resolve('.test-output/fixtures');const logs=[];fs.mkdirSync('.test-output/screenshots',{recursive:true});
const server=http.createServer((req,res)=>{const name=decodeURIComponent(req.url.split('?')[0]).replace(/^\//,'')||'index.html';const file=path.resolve(root,name);if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.writeHead(404).end();return;}res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':file.endsWith('.json')?'application/json':'text/html');res.end(fs.readFileSync(file));});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));
const url=`http://127.0.0.1:${server.address().port}/index.html`;
const browser=await chromium.launch({...(process.env.MIRSAD_CHROME ? {executablePath:process.env.MIRSAD_CHROME} : {}),headless:true});
const errors=[];
const check=(cond,msg)=>{logs.push({pass:!!cond,message:msg});if(!cond)throw Error(msg);};
try{
for(const width of [320,375,430,768,1366,1920]){
 const page=await browser.newPage({viewport:{width,height:1000},colorScheme:'dark'});
 page.on('pageerror',e=>errors.push(e.message));
 await page.clock.install({time:new Date('2026-10-19T14:10:00Z')});
 await page.route('https://**/*',r=>r.abort());
 await page.goto(url);await page.waitForFunction(()=>document.querySelector('#output').hidden===false);
 await page.waitForFunction(()=>typeof GAMMA!=='undefined' && GAMMA && GAMMA.price_history);
 check(await page.locator('#mAdvice').isVisible(),`${width}: advice visible`);
 check(await page.locator('#sessionAside').isVisible(),`${width}: event and risk share aside`);
 check(await page.locator('#mainCard').evaluate(n=>n.getBoundingClientRect().top < document.getElementById('updCard').getBoundingClientRect().top),`${width}: advice before update details`);
 check(await page.locator('#gammaDiagnostics').evaluate(n=>!n.open),`${width}: strike diagnostics initially collapsed`);
 check(await page.locator('#nextCard').isVisible(),`${width}: next event visible`);
 check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),`${width}: no page horizontal overflow`);
 check(await page.locator('#pulseDetails').evaluate(d=>d.open)===(width>=900),`${width}: market disclosure responsive`);
 if(width<900){await page.locator('#pulseDetails summary').click();check(await page.locator('#pcards').isVisible(),`${width}: market details open`);}
 await page.locator('#gammaJump').click();
 check(await page.locator('#gPriceMap svg').count()===1,`${width}: time-price chart rendered`);
 check(await page.locator('#gPriceMap').innerText().then(t=>t.includes('Gamma Regime معطلة')),`${width}: no unsupported regime`);
 const sel=page.locator('#gPriceMap select');await sel.selectOption('SPY');
 check(await page.locator('#gPriceMap svg').count()===1,`${width}: SPY chart`);
 await sel.selectOption('Combined');
 check(await page.locator('#gPriceMap svg').count()===1,`${width}: Combined chart`);
 check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),`${width}: gamma scroll confined`);
 if(width===430||width===1366){
  await page.evaluate(()=>{const m=document.createElement('div');m.textContent='اختبار الواجهة — بيانات توضيحية وليست قراءة سوق';m.style.cssText='background:#6c4c00;color:white;padding:10px;text-align:center;font-size:16px;margin-bottom:14px';document.querySelector('.wrap').prepend(m);});
  await sel.selectOption('SPX');
  await page.screenshot({path:`.test-output/screenshots/mirsad-final-gamma-${width}.png`,fullPage:true});
  await page.evaluate(()=>{showTab('today');window.scrollTo(0,0);});
  if(width<900) await page.locator('#pulseDetails').evaluate(n=>n.open=false);
  await page.screenshot({path:`.test-output/screenshots/mirsad-final-today-${width}.png`,fullPage:true});
  await page.screenshot({path:`.test-output/screenshots/mirsad-today-viewport-${width}.png`});
 }
 await page.evaluate(()=>showTab('gamma'));
 await page.locator('#gammaDiagnostics summary').click();
 check(await page.locator('#gChart').isVisible(),`${width}: retained strike chart expands`);
 // Invalid/old SPY must never leave a previous chart overlay behind.
 await page.evaluate(()=>{GAMMA.spy.snapshot_utc='2026-10-18T14:00:00Z';gammaMapAsset='SPY';renderPriceMap_(GAMMA);});
 check(await page.locator('#gPriceMap').innerText().then(t=>t.includes('المستويات معطلة')),`${width}: stale SPY blocked`);
 if(width===430){
  const history=await page.evaluate(()=>GAMMA.price_history);
  await page.route('**/gamma.json*',r=>r.fulfill({json:{ok:false,reason:'TEST source unavailable'}}));
  await page.route('**/price.json*',r=>r.fulfill({json:history}));
  await page.evaluate(()=>loadGamma_());
  check(await page.evaluate(()=>!GAMMA.ok && GAMMA.price_history.ok),'Independent price response loads while gamma API fails');
  check(await page.locator('#gPriceMap svg').count()===1,'Independent price chart remains visible');
 }
 await page.evaluate(()=>{GAMMA.ok=false;gammaMapAsset='SPX';renderPriceMap_(GAMMA);});
 check(await page.locator('#gPriceMap svg').count()===1,`${width}: price survives unavailable gamma`);
 await page.evaluate(()=>{GAMMA.price_history.ok=false;renderPriceMap_(GAMMA);});
 check(await page.locator('#gPriceMap svg').count()===0,`${width}: missing history clears chart`);
 await page.evaluate(()=>{GAMMA=null;renderPriceMap_(GAMMA);});
 check(await page.locator('#gPriceMap').innerText().then(t=>t.includes('شارت السعر غير متاح')),`${width}: no data empty state`);
 await page.close();
}
check(errors.length===0,'No uncaught browser errors: '+errors.join('; '));
}finally{await browser.close();server.close();fs.writeFileSync('.test-output/ui-checks.json',JSON.stringify(logs,null,2));}
console.log(`${logs.filter(r=>r.pass).length} browser checks passed`);
})().catch(e=>{console.error(e);server.close();process.exitCode=1});
