from pathlib import Path
import os,sys,json,shutil
root=Path(__file__).resolve().parent
source=root
os.environ['TEMP']=os.environ['TMP']=str(root/'.test-output/tmp')
(root/'.test-output/tmp').mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root))
os.chdir(root)
import tests_browser as tb
from tests_gamma_v022 import raw_chain,T,spy_ref
import gamma
from datetime import timedelta,datetime,timezone
fx=tb.rich(tb.build_fixture());fx['version']='0.22.0'
fixture=root/'.test-output/fixtures';fixture.mkdir(parents=True,exist_ok=True)
for f in ('index.html','gamma-map.js','layout-v022.css','layout-v022.js','manifest.webmanifest'):
    shutil.copy2(root/f,fixture/f)
shutil.copytree(root/'icons',fixture/'icons',dirs_exist_ok=True)
(fixture/'data.json').write_text(json.dumps(fx,ensure_ascii=False),encoding='utf-8')
snap=gamma.build(raw_chain(),fetched=T+timedelta(minutes=10),with_es=False)
snap['spy']=gamma.build_spy(T,T+timedelta(minutes=10),T.date(),ref=spy_ref(),raw=raw_chain('SPY'))
snap['combined']=gamma.combined(snap)
pts=[{'time':(T-timedelta(minutes=70-i*5)).isoformat(),'close':6998+i*.35+(i%3-1)*1.2} for i in range(17)]
snap['price_history']={'ok':True,'asset':'SPX','interval':'5m','source':'TEST FIXTURE — بيانات اختبار توضيحية','fetched_utc':snap['fetched_utc'],'points':pts}
(fixture/'gamma.json').write_text(json.dumps(snap,ensure_ascii=False),encoding='utf-8')
print('fixture ready')
